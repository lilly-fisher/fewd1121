// $('.sectionA').click(function(){

// 	$('.sectionA').css({'background-color':'red', 'height':'500px','color':'white'}).html("Hello There!");

// });


// $('.sectionB').click(function(){

// 	$('.sectionB').css({'background-color':'red', 'height':'500px','color':'white'}).html("Hello There!");

// });


$('.mike').click(function(){

	$(this).css({'background-color':'red', 'height':'500px','color':'white'}).html("Hello There!");

});

